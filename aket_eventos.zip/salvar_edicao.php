<?php
    session_start();
    if (!isset($_SESSION['aketadm']))
    {
        header("Location: login_admin.php");
        exit();
    }
    
    require "conexao.php";

    if ($_SERVER['REQUEST_METHOD'] !== 'POST')
    {
        header("Location: listar_cadastros.php");
        exit();
    }

    $id = intval($_POST['id']);
    $nome = $_POST['nome'];
    $idade = intval($_POST['idade']);
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $imagemURL = $_POST['imagemURL'];

    $stmt = $con -> prepare("UPDATE cadastro SET nome = ?, idade = ?, email = ?, telefone = ?, imagemURL = ? WHERE id = ?");
    $stmt -> bind_param("sisssi", $nome, $idade, $email, $telefone, $imagemURL, $id);

    if ($stmt -> execute())
    {
        echo
        "<script>
            alert('Alterações salvas com sucesso!');
            window.location.href = 'listar_cadastros.php';
        </script>";
        exit();
    }
    else
    {
        echo
        "<script>
            alert('Erro ao salvar alterações');
            history.back();
        </script>";
        exit();
    }
?>