<?php
    $con = new mysqli("localhost", "root", "", "aket_eventos");

    if ($con -> connect_error)
    {
        die("Erro na conexão: " . $con -> connect_error);
    }
?>