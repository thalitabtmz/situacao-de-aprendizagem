<?php
    session_start();

    // Usuário e senha definidos por você
    $usuarioCorreto = "aketadm";
    $senhaCorreta = "951357";

    $usuario = $_POST['usuario'] ?? "";
    $senha = $_POST['senha'] ?? "";

    // Verifica login
    if ($usuario === $usuarioCorreto && $senha === $senhaCorreta)
    {
        $_SESSION['aketadm'] = true;
        header("Location: painel_admin.php");
        exit();
    }

    // Senha errada
    echo
    "<script>
        alert('Usuário ou senha incorretos!');
        window.location.href = 'login_admin.php';
    </script>";
    exit();
?>