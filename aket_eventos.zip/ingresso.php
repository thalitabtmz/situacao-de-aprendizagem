<?php
    // Verifica se o formulário foi enviado
    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        $nome = htmlspecialchars($_POST["nome"]);
        $idade = intval($_POST["idade"]);
        $email = htmlspecialchars($_POST["email"]);
        $telefone = htmlspecialchars($_POST["telefone"]);

        // Conteúdo que irá dentro do QR Code (ingresso)
        $conteudoQR = "INGRESSO FESTIVAL 2025\n";
        $conteudoQR .= "Nome: $nome\n";
        $conteudoQR .= "Idade: $idade\n";
        $conteudoQR .= "Email: $email\n";
        $conteudoQR .= "Telefone: $telefone";

        // Codifica para URL
        $qrCodeURL = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=" . urlencode($conteudoQR);
    }
?>

<html lang = "pt-br">
    <head>
        <meta charset = "UTF-8">
        <title> Ingresso com QR Code </title>

        <style>
            body
            {
                font-family: Arial, sans-serif;
                background: linear-gradient(to bottom, #d5b8ec, #7612d3);
                min-height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
            }

            .container
            {
                background: white;
                padding: 40px;
                border-radius: 10px;
                width: 420px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            }

            h2
            {
                text-align: center;
                color: #7612d3;
            }

            label
            {
                display: block;
                margin-top: 15px;
            }

            input
            {
                width: 100%;
                height: 35px;
                padding: 5px;
                margin-top: 5px;
            }

            button
            {
                width: 100%;
                margin-top: 20px;
                height: 40px;
                background: #c884ff;
                border: none;
                color: white;
                font-size: 15px;
                border-radius: 5px;
                cursor: pointer;
            }

            .ingresso
            {
                margin-top: 30px;
                border: 2px dashed #7612d3;
                padding: 20px;
                border-radius: 10px;
                text-align: center;
            }
        </style>
    </head>

    <body>
        <div class = "container">
            <h2> Cadastro - Festival 2025 </h2>

            <form method = "POST">
                <label> Nome: <input type = "text" name = "nome" required></label>
                <label> Idade: <input type = "number" name = "idade" required></label>
                <label> Email:
                <input type = "email" name = "email" required></label>
                <label> Telefone: <input type = "text" name = "telefone" required></label>

                <button type = "submit"> Gerar Ingresso </button>
            </form>

            <?php
                if (!empty($qrCodeURL))
                {
                    ?>
                    <div class = "ingresso">
                        <h3> INGRESSO DIGITAL </h3>

                        <p><strong> Evento: </strong> Festival de Shows 2025</p>
                        <p><strong> Nome: </strong> <?= $nome ?></p>
                        <p><strong> Email: </strong> <?= $email ?></p>

                        <img src = "<?= $qrCodeURL ?>" alt = "QR Code do ingresso">

                        <p style = "font-size:12px; margin-top:10px;">
                            Apresente este QR Code na entrada
                        </p>
                    </div>
                <?php
                }
            ?>
        </div>
    </body>
</html>