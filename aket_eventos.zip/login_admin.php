<?php
    session_start();

    // Se já estiver logado, vai direto ao painel
    if (isset($_SESSION['aketadm']))
    {
        header("Location: painel_admin.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang = "pt-br">
    <head>
        <meta charset = "UTF-8">
        <title> Login do Administrador </title>

        <style>
            body
            {
                margin: 0;
                padding: 0;
                font-family: Arial, sans-serif;
                background: linear-gradient(to bottom, #d5b8ec, #7612d3);
                height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
            }

            .card
            {
                background: #ffffffdd;
                width: 350px;
                padding: 30px;
                border-radius: 12px;
                box-shadow: 0 8px 20px rgba(0,0,0,0.25);
                text-align: center;
            }

            h2
            {
                color: #5d0fa5;
                margin-bottom: 20px;
            }

            label
            {
                display: block;
                text-align: left;
                font-weight: bold;
                color: #4a136f;
                margin-top: 12px;
            }

            input
            {
                width: 100%;
                padding: 12px;
                margin-top: 6px;
                border: 1px solid #b97ae0;
                border-radius: 8px;
                font-size: 15px;
            }

            button
            {
                width: 100%;
                margin-top: 20px;
                padding: 12px;
                background-color: #9b4de8;
                border: none;
                border-radius: 10px;
                color: white;
                font-size: 17px;
                font-weight: bold;
                cursor: pointer;
                box-shadow: 2px 2px 8px rgba(0,0,0,0.25);
                transition: 0.3s;
            }

            button:hover
            {
                background-color: #6f2ca8;
                transform: scale(1.03);
            }

            .voltar
            {
                display: inline-block;
                margin-top: 15px;
                text-decoration: none;
                color: #5d0fa5;
                font-weight: bold;
            }
        </style>
    </head>

    <body>
        <div class = "card">
            <h2> Login do Administrador </h2>

            <form action = "fazer_login.php" method = "POST">
                <label> Usuário: </label>
                <input type = "text" name = "usuario" placeholder = "Digite o usuário" required>
                
                <label> Senha </label>
                <input type = "password" name = "senha" placeholder = "Digite a senha" required>

                <button type = "submit"> Entrar </button>
            </form>

            <a class = "voltar" href = "index.html"> Voltar ao Início </a>
        </div>
    </body>
</html>