<?php
    session_start();
    if (!isset($_SESSION['aketadm']))
    {
        header("Location: login_admin.php");
        exit();
    }
    require "conexao.php";

    if (!isset($_GET['id']))
    {
        header("Location: listar_cadastros.php");
        exit();
    }

    $id = intval($_GET['id']);

    $stmt = $con -> prepare("SELECT id, nome, idade, email, telefone, imagemURL FROM cadastro WHERE id = ?");
    $stmt -> bind_param("i", $id);
    $stmt -> execute();
    $res = $stmt -> get_result();
    $dados = $res -> fetch_assoc();

    if (!$dados)
    {
        echo
            "Registro não encontrado.";
        exit();
    }
?>

<!DOCTYPE html>
<html lang = "pt-br">
    <head>
        <meta charset = "UTF-8">
        <title> Editar Cadastro </title>

        <style>
            body
            {
                font-family: Segoe UI, Tahoma;
                background: linear-gradient(to bottom,#d5b8ec,#7612d3);
                min-height: 100vh;
                padding: 60px 20px;
            }

            .card
            {
                max-width: 520px;
                margin: 20px auto;
                background: #ffffffdd;
                padding: 26px;
                border-radius: 12px;
                box-shadow: 0 8px 20px rgba(0,0,0,.15);
            }

            h2
            {
                color: #5d0fa5;
                text-align: center;
            }

            label
            {
                display: block;
                margin-top: 12px;
                color: #444;
                font-weight: 600;
            }

            input
            {
                width: 100%;
                padding: 10px;
                border: 1px solid #b97ae0;
                border-radius: 8px;
                margin-top: 6px;
            }

            button
            {
                width: 100%;
                margin-top: 18px;
                padding: 12px;
                background: #9b4de8;
                color: #fff;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                cursor: pointer
            }

            button:hover
            {
                background: #6f2ca8;
                transform: scale(1.02);
            }

            .cancel
            {
                display: block;
                text-align: center;
                margin-top: 12px;
                color: #5d0fa5;
                text-decoration: none;
                font-weight: bold;
            }
        </style>
    </head>

    <body>
        <div class = "card">
            <h2> Editar Cadastro <?= htmlspecialchars($dados['id']) ?></h2>

            <form action = "salvar_edicao.php" method = "POST">
                <input type = "hidden" name = "id" value = "<?= htmlspecialchars($dados['id']) ?>">

                <label> Nome: </label>
                <input type = "text" name = "nome" value = "<?= htmlspecialchars($dados['nome']) ?>" required>
                
                <label> Idade: </label>
                <input type = "number" name = "idade" value = "<?= htmlspecialchars($dados['idade']) ?>" required>
                
                <label> E-mail: </label>
                <input type = "email" name = "email" value = "<?= htmlspecialchars($dados['email']) ?>" required>
                
                <label> Telefone: </label>
                <input type = "text" name = "telefone" value = "<?= htmlspecialchars($dados['telefone']) ?>" required>
                
                <label> URL da Imagem: </label>
                <input type = "url" name = "imagemURL" value = "<?= htmlspecialchars($dados['imagemURL']) ?>">

                <button type = "submit"> Salvar Alterações </button>
            </form>

            <a class = "cancel" href = "listar_cadastros.php"> Voltar </a>
        </div>
    </body>
</html>