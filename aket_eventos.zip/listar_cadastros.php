<?php
    session_start();
    if (!isset($_SESSION['aketadm']))
    {
        header("Location: login_admin.php");
        exit();
    }
    require "conexao.php";

    $sql = "SELECT * FROM cadastro ORDER BY id DESC";
    $result = $con -> query($sql);
?>

<!DOCTYPE html>
<html lang = "pt-br">
    <head>
        <meta charset = "UTF-8">
        <title> Lista de Cadastros </title>

        <style>
            *
            {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }

            body
            {
                font-family: Segoe UI, Tahoma, Arial;
                background: linear-gradient(to bottom,#d5b8ec,#7612d3);
                min-height: 100vh;
                padding: 100px 20px;
            }

            header
            {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                background: #34135f;
                color: #fff;
                padding: 16px 20px;
                box-shadow: 0 2px 10px rgba(0,0,0,.1);
            }

            .container
            {
                max-width: 1100px;
                margin: 0 auto;
            }

            .card
            {
                background: #e9cfffd9;
                padding: 18px;
                border-radius: 12px;
                box-shadow: 0 8px 20px rgba(0,0,0,.15);
            }

            h1
            {
                color: #34135f;
                margin-bottom: 12px;
            }

            .table
            {
                width: 100%;
                border-collapse: collapse;
                margin-top: 12px;
            }

            .table th
            {
                background: #c884ff;
                color: #fff;
                padding: 12px;
                text-align: center;
            }

            .table td
            {
                padding: 12px;
                text-align: center;
                border-bottom: 1px solid rgba(0,0,0,.08);
            }

            img
            {
                height: 60px;
                border-radius: 8px;
            }

            .btn
            {
                display: inline-block;
                padding: 8px 12px;
                border-radius: 8px;
                color: #fff;
                text-decoration: none;
                font-weight: bold;
                margin: 2px;
            }

            .btn.editar
            {
                background: #7d3cc7;
            }

            .btn.excluir
            {
                background: #d13b3b;
            }

            .top-actions
            {
                margin-top: 12px;
                margin-bottom: 10px;
            }

            .top-actions a
            {
                margin-right: 10px;
                padding: 8px 14px;
                background: #c884ff;
                color: #fff;
                text-decoration: none;
                border-radius: 8px;
            }

            .top-actions a:hover
            {
                background: #6f369e;
            }

            .logout
            {
                background: #e04b4b;
            }

            .logout:hover
            {
                background: #b53434;
            }
        </style>
    </head>

    <body>
        <header>
            <div style = "display: flex; justify-content: space-between; align-items: center">
                <div> FESTIVAL DE SHOWS 2025 — Área Administrativa </div>
                <div>
                    <a href = "painel_admin.php" style = "color: #fff; text-decoration: none; margin-right: 12px"> Painel </a>
                    <a class = "logout" href = "logout.php" style = "color: #fff; text-decoration: none; padding: 8px 12px; border-radius: 8px; background: #e04b4b"> Sair </a>
                </div>
            </div>
        </header>

        <div class = "container">
            <div class = "card">
                <h1> Lista de Cadastros </h1>

                <div class = "top-actions">
                    <a href = "1index.html"> Novo Cadastro </a>
                    <a href = "index.html">Ver: Site </a>
                </div>

                <table class = "table">
                    <tr>
                        <th> ID </th>
                        <th> Nome </th>
                        <th> Idade </th>
                        <th> Email </th>
                        <th> Telefone </th>
                        <th> Imagem </th>
                        <th> Ações </th>
                    </tr>

                <?php while ($row = $result -> fetch_assoc())
                {
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id']) ?></td>
                        <td><?= htmlspecialchars($row['nome']) ?></td>
                        <td><?= htmlspecialchars($row['idade']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['telefone']) ?></td>
                        <td>

                        <?php
                            if (!empty($row['imagemURL'])):
                        ?>
                    
                        <img src = "<?= htmlspecialchars($row['imagemURL']) ?>" alt = "">
                        
                        <?php
                            endif;
                        ?>
                        </td>

                        <td>
                            <a class = "btn editar" href = "editar_cadastro.php?id =
                            <?= $row['id'] ?>"> Editar </a>

                            <a class = "btn excluir" href = "excluir_cadastro.php?id =
                            <?= $row['id'] ?>" onclick = "return confirm('Deseja excluir este cadastro?')"> Excluir </a>
                        </td>
                    </tr>
                <?php
                }
                ?>
            </table>
        </div>
    </body>
</html> 