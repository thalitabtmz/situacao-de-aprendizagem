<?php
    require "conexao.php";

    $nome = $_POST['nome'];
    $idade = $_POST['idade'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $imagemURL = $_POST['imagemURL'];

    // Senha criptografada
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);

    $sql = $con -> prepare("INSERT INTO cadastro (nome, idade, email, telefone, imagemURL, senha) VALUES (?, ?, ?, ?, ?, ?)");
    $sql -> bind_param("sissss", $nome, $idade, $email, $telefone, $imagemURL, $senha);

    if ($sql -> execute())
    {
        echo
        "<script>
            alert('Cadastro realizado com sucesso!');
            window.location.href='login.html';
        </script>";
    }
    else
    {
        echo
        "<script>
            alert('Erro ao cadastrar!');
            history.back();
        </script>";
    }
?>