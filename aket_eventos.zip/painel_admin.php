<?php
    session_start();
    if (!isset($_SESSION['aketadm']))
    {
        header("Location: login_admin.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang = "pt-br">
    <head>
        <meta charset = "UTF-8">
        <title> Painel Administrativo </title>

        <style>
            body
            {
                font-family: Arial, sans-serif;
                margin: 0;
                background: linear-gradient(to bottom,#d5b8ec,#7612d3);
                min-height: 100vh;
            }

            .header
            {
                background: #34135f;
                color: #fff;
                padding: 18px 20px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .container
            {
                max-width: 1100px;
                margin: 40px auto;
                padding: 20px;
            }

            .card
            {
                background: #fff;
                padding: 20px;
                border-radius: 12px;
                box-shadow: 0 8px 20px rgba(0,0,0,0.15);
            }

            .links a
            {
                display: inline-block;
                margin: 8px;
                padding: 12px 18px;
                background: #c884ff;
                color: #fff;
                border-radius: 8px;
                text-decoration: none;
                font-weight: bold;
            }

            .links a:hover
            {
                background: #6f369e;
            }

            .logout
            {
                background: #e04b4b;
            }

            .logout:hover
            {
                background: #b53434;
            }

            .info
            {
                color: #34135f;
                margin-bottom: 10px;
            }

            .quick
            {
                display: flex;
                flex-wrap: wrap;
                gap: 12px;
                margin-top: 12px;
            }

            .quick a
            {
                padding: 12px 18px;
                background: #9b4de8;
                color: white;
                border-radius: 8px;
                text-decoration: none;
                font-weight: bold;
            }

            .quick a:hover
            {
                background: #6f2ca8;
                transform: translateY(-2px);
            }

            .footer-note
            {
                margin-top: 14px;
                color: #555;
                font-size: 14px;
            }
        </style>
    </head>

    <body>
        <div class = "header">
            <div><strong> Painel Administrativo </strong></div>
                <div>
                    <a href = "index.html" style = "color: #fff; text-decoration: none; margin-right: 16px"> Site </a>
                    <a class = "links logout" href = "logout.php" style = "background: #e04b4b; padding: 8px 12px; border-radius: 8px; color: #fff; text-decoration: none"> Sair </a>
                </div>
            </div>

            <div class = "container">
                <div class = "card">
                    <h2 style = "margin-top: 0; color: #34135f"> Bem-vindo, administrador </h2>
                    <p class = "info"> Aqui você gerencia os cadastros do festival e as páginas internas. </p>

                    <div class = "quick">
                        <a href = "listar_cadastros.php"> Gerenciar Cadastros </a>
                        <a href = "1index.html"> Novo Cadastro </a>
                        <a href = "2index.html"> Ver: Programação </a>
                        <a href = "ANA.html"> Ver: Ana Castela </a>
                        <a href = "ALOK.html"> Ver: Alok </a>
                        <a href = "LUAN.html"> Ver: Luan Santana </a>
                    </div>

                <div class = "footer-note">
                    <strong> Gerenciar Cadastros </strong>
                </div>
            </div>
        </div>
    </body>
</html>